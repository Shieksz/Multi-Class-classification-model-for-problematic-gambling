# Install and load the required libraries
install.packages("randomForest")
library(randomForest)
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("impute", force = TRUE)
library("impute")
install.packages("VIM")
library(VIM)
install.packages("psych")
library(psych)
install.packages("ROCR")
library(ROCR)
library(readxl)
install.packages("caret")
library(caret)

eSports_Gambling_risk_study_1_285_ <- read_excel("eSports Gambling risk study(1-285).xlsx")

Main_data <- eSports_Gambling_risk_study_1_285_

# Remove columns 1 to 9
Main_data <- Main_data[, -c(1:9)]
Main_data <- Main_data[, -11, -41]

# Assuming your data frame is named Main_data
answer_mapping <- c('Never' = 0, 'Sometimes' = 1, 'Most of the time' = 2, 'Almost always' = 3)

# Columns 29 to 37
answer_columns <- Main_data[, 23:31]

# Apply the mapping using sapply
mapped_answers <- sapply(answer_columns, function(column) {
  sapply(column, function(answer) {
    answer_mapping[as.character(answer)]
  })
})

# Create a new column with the total scores
Main_data$PGSI_score <- rowSums(mapped_answers, na.rm = TRUE)

# Remove observations where Age is Under 18 and Level of education is Bachelors, Masters, or PhD
Main_data <- Main_data[!(trimws(Main_data$Age) == "Under 18" & Main_data$`Level of education?` %in% c("Bachelor", "Master", "PhD")), ]

# Renaming column headers#
names(Main_data)[3] <- "Region"
names(Main_data)[4] <- "Education"
names(Main_data)[5] <- "View time"
names(Main_data)[6] <- "Income"
names(Main_data)[7] <- "Gaming time"
names(Main_data)[8] <- "Games played"
names(Main_data)[10] <- "Game for rewards"
names(Main_data)[11] <- "Gambling interest"
names(Main_data)[12] <- "Gambling Platform"
names(Main_data)[13] <- "Gambling Spend"
names(Main_data)[14] <- "Gambling Deposit"
names(Main_data)[15] <- "Gambling Games"
names(Main_data)[16] <- "Gambling Events"
names(Main_data)[17] <- "Gambling Bets"
names(Main_data)[18] <- "Gambling Motivation"
names(Main_data)[19] <- "Sport betting"
names(Main_data)[20] <- "Gambling Length"
names(Main_data)[21] <- "Gambling Frequency"
names(Main_data)[21] <- "Gambling Change"
names(Main_data)[25] <- "Gambling Frequency"
names(Main_data)[33] <- "Third Party"
names(Main_data)[34] <- "3rd Gambling spend"
names(Main_data)[35] <- "3rd Party Esports"
names(Main_data)[36] <- "3rd Party Gambling Change"
names(Main_data)[37] <- "3rd Party Bet frequency"
names(Main_data)[39] <- "3rd Party Events"
names(Main_data)[40] <- "3rd Party Games"


#Remove columns 23 : 31 (PGSI responses)#
Main_data <- Main_data[, -c(23:31)]

# Assuming 'Main_data' is your dataset
Main_data <- Main_data[Main_data[, 9] != "No", ]


# Replace missing values with NAs
Main_data[Main_data == ""] <- NA

# Perform k-Nearest Neighbors imputation
imputed_data <- kNN(Main_data, k = 5)

# Extract column names from the original data
original_column_names <- colnames(Main_data)

# Select only the columns present in the original dataset
imputed_data <- imputed_data[, original_column_names]

#Two seperate data sets for those who gamble on Esports vs those who gamble on Esports & 3rd Party#
# Create a subset for Third-party gamblers#
Third_party_platforms <- imputed_data[imputed_data$`Third Party` %in% c("Yes", "Maybe"), ]

# Assuming 'imputed_data' is your data frame
columns_to_keep <- c(1:23, ncol(imputed_data))  # Columns 1 to 24 and the last column
Non_Third_party_platforms <- imputed_data[, columns_to_keep]

# Function to split and create new columns
split_and_create_columns <- function(data, column_name) {
  split_values <- strsplit(as.character(data[[column_name]]), ';')
  unique_values <- unique(unlist(split_values))
  
  for (value in unique_values) {
    data[[paste0(column_name, "_", value)]] <- sapply(split_values, function(x) as.numeric(value %in% x))
  }
  
  data[[column_name]] <- NULL
  return(data)
}

# List of columns to split for both data sets
columns_to_split_third <- c("Games played", "Gambling interest", "Gambling Platform","Gambling Deposit", 
                            "Gambling Games","Gambling Events", "Gambling Bets", "Gambling Motivation",
                            "Sport betting", "3rd Party Esports", "3rd Party Events", "3rd Party Games")

# Apply the function to each column of General gambling data set
for (column in columns_to_split_third) {
  Non_Third_party_platforms <- split_and_create_columns(Non_Third_party_platforms, column)
}

# Apply the function to each column of 
for (column in columns_to_split_third) {
  Third_party_platforms <- split_and_create_columns(Third_party_platforms, column)
}

Non_Third_party_platforms <- data.frame(lapply(Non_Third_party_platforms, function(x) {
  if (is.character(x)) {
    as.factor(x)
  } else {
    x
  }
}))

#desc_stats <- describe(imputed_data)

# Assuming 'imputed_data' is your dataset
unique_regions <- unique(Non_Third_party_platforms$Region)

# Create a list to store subsets
Non_subset_third <- list()

# Loop through each unique region and create a subset
for (region in unique_regions) {
  Non_subset_data <- subset(Non_Third_party_platforms, Region == region)
  Non_subset_third[[region]] <- Non_subset_data
}

# Create a list to store subsets
subset_third <- list()

# Loop through each unique region and create a subset
for (region in unique_regions) {
  subset_third_data <- subset(Third_party_platforms, Region == region)
  subset_third[[region]] <- subset_third_data
}

# Create a binary target variable indicating PGSI score of 5 and above
Non_Third_party_platforms$binary_PGSI <- ifelse(Non_Third_party_platforms$PGSI_score >= 8, 1, 0)

# Split the dataset into training and testing sets
set.seed(123)  # For reproducibility
sample_index <- sample(1:nrow(Non_Third_party_platforms), 0.7 * nrow(Non_Third_party_platforms))
train_data <- Non_Third_party_platforms[sample_index, ]
test_data <- Non_Third_party_platforms[-sample_index, ]

# Convert character columns to factors for train_data
train_data <- data.frame(lapply(train_data, function(x) {
  if (is.character(x)) {
    as.factor(x)
  } else {
    as.numeric(x)
  }
}))

# Convert character columns to factors for test_data
test_data <- data.frame(lapply(test_data, function(x) {
  if (is.character(x)) {
    as.factor(x)
  } else {
    as.numeric(x)
  }
}))


# Convert character columns to factors
Non_Third_party_platforms <- data.frame(lapply(Non_Third_party_platforms, function(x) {
  if (is.character(x)) {
    as.factor(x)
  } else {
    as.numeric(x)
  }
}))

# Create a control function for cross-validation
ctrl <- trainControl(method = "cv", number = 5)  # 5-fold cross-validation

# Train the Random Forest model
rf_model <- randomForest(PGSI_score ~ ., data = train_data, ntree = 500, importance = TRUE)

# Make predictions on the test set
predictions <- predict(rf_model, newdata = test_data)

# Convert probabilities to binary predictions
binary_predictions <- ifelse(predictions >= 0.5, 1, 0)

# Convert to factors
binary_predictions <- as.factor(binary_predictions)
test_data$binary_PGSI <- as.factor(test_data$binary_PGSI)

# Ensure both have the same levels
levels(binary_predictions) <- levels(test_data$binary_PGSI)

# confusion matrix
conf_matrix <- confusionMatrix(binary_predictions, test_data$binary_PGSI)
print(conf_matrix)

# Additional metrics
accuracy <- conf_matrix$overall["Accuracy"]
precision <- conf_matrix$byClass["Precision"]
recall <- conf_matrix$byClass["Recall"]
f1 <- conf_matrix$byClass["F1"]

# Print performance metrics
cat("Accuracy:", accuracy, "\n")
cat("Precision:", precision, "\n")
cat("Recall:", recall, "\n")
cat("F1 Score:", f1, "\n")

# Assuming you have binary outcomes (0 or 1) in the test_data$binary_PGSI column
actual_labels <- test_data$binary_PGSI

# Calculate AUROC
roc_curve <- roc(actual_labels, predictions)
auroc <- auc(roc_curve)
auroc_ci <- ci.auc(roc_curve)

# Calculate AUCPR
pr_curve <- pr.curve(scores.class0 = predictions, weights.class0 = actual_labels)
aucpr <- pr.curve$auc.integral

# Calculate F1 Max
f1_max <- maxF1(actual_labels, predictions)

# Calculate Specificity at 80% Sensitivity
sensitivity_target <- 0.8
specificity_at_sensitivity <- specificity(roc_curve, sens = sensitivity_target)

# Calculate Sensitivity at 80% Specificity
specificity_target <- 0.8
sensitivity_at_specificity <- sensitivity(roc_curve, spec = specificity_target)

# Calculate Youden's Index
youden_index <- roc_curve$sensitivities[which.max(roc_curve$sensitivities + roc_curve$specificities - 1)]

# Calculate Sensitivity at Youden's cutoff
sensitivity_at_youden <- roc_curve$sensitivities[which.max(roc_curve$sensitivities + roc_curve$specificities - 1)]

# Calculate Specificity at Youden's cutoff
specificity_at_youden <- roc_curve$specificities[which.max(roc_curve$sensitivities + roc_curve$specificities - 1)]

# Print the results
cat("AUROC:", round(auroc, 4), "\n")
cat("AUROC CI:", round(auroc_ci[1], 4), "-", round(auroc_ci[2], 4), "\n")
cat("AUCPR:", round(aucpr, 4), "\n")
cat("F1 Max:", round(f1_max, 4), "\n")
cat("Specificity at", sensitivity_target * 100, "% Sensitivity:", round(specificity_at_sensitivity, 4), "\n")
cat("Sensitivity at", specificity_target * 100, "% Specificity:", round(sensitivity_at_specificity, 4), "\n")
cat("Youden's Index:", round(youden_index, 4), "\n")
cat("Sensitivity at Youden's cutoff:", round(sensitivity_at_youden, 4), "\n")
cat("Specificity at Youden's cutoff:", round(specificity_at_youden, 4), "\n")
