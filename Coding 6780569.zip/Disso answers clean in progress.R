#Install required packages #
install.packages("corrplot")
install.packages("dplyr")
install.packages("knitr")
if (!require("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("impute", force = TRUE)
library("impute")
install.packages("VIM")
library(VIM)

library(readxl)
library(Rcpp)
library(corrplot)
library(dplyr)
library(ggplot2)
library(knitr)
library(tidyr)
library(psych)

# Load file#
eSports_Gambling_risk_study_1_285_1_ <- read_excel("eSports Gambling risk study(1-285) (1).xlsx")

# Make duplicate to modify #
Main_data <- eSports_Gambling_risk_study_1_285_1_

# Remove columns 1 to 9 unecessary and to preserve anonymity#
Main_data <- Main_data[, -c(1:9)]

# Renaming column headers#
names(Main_data)[3] <- "Region"
names(Main_data)[4] <- "Education"
names(Main_data)[5] <- "View time"
names(Main_data)[6] <- "Income"
names(Main_data)[7] <- "Gaming time"
names(Main_data)[8] <- "Games played"
names(Main_data)[9] <- "Esport gamble"
names(Main_data)[10] <- "Game for rewards"
names(Main_data)[12] <- "Gambling interest"
names(Main_data)[13] <- "Gambling Platform"
names(Main_data)[14] <- "Gambling Spend"
names(Main_data)[15] <- "Gambling Deposit"
names(Main_data)[16] <- "Gambling Esport"
names(Main_data)[17] <- "Gambling Events"
names(Main_data)[18] <- "Gambling Bets"
names(Main_data)[19] <- "Gambling Motivation"
names(Main_data)[20] <- "Sport betting"
names(Main_data)[21] <- "Gambling Length"
names(Main_data)[22] <- "Gambling Frequency"
names(Main_data)[23] <- "Gambling Change"
names(Main_data)[22] <- "Gambling Frequency"
names(Main_data)[34] <- "Third Party"
names(Main_data)[35] <- "3rd Gambling spend"
names(Main_data)[36] <- "3rd Party Esports"
names(Main_data)[37] <- "3rd Party Gambling Change"
names(Main_data)[38] <- "3rd Party Bet frequency"
names(Main_data)[40] <- "3rd Party Events"
names(Main_data)[41] <- "3rd Party Games"

# Visualising health along gambling frequency and region #
Third_party_platforms_health <- Main_data[Main_data$`Third Party` %in% c("Yes", "Maybe"),]
names(Third_party_platforms_health)[29] <- "Health"

# Answer Mapping PGSI scores
answer_mapping <- c('Never' = 0, 'Sometimes' = 1, 'Most of the time' = 2, 'Almost always' = 3)

# Columns 29 to 37
answer_columns <- Main_data[, 23:31]

# Apply the mapping using sapply
mapped_answers <- sapply(answer_columns, function(column) {
  sapply(column, function(answer) {
    answer_mapping[as.character(answer)]
  })
})

# Create a new column with the total scores
Main_data$PGSI_score <- rowSums(mapped_answers, na.rm = TRUE)


#Remove columns 23 : 31 (PGSI responses)#
Esports_gamblers <- Main_data[, -c(23:32)]


#Create a data frame for Esports gamblers seperate from original data set#
Esports_gamblers <- Esports_gamblers[Esports_gamblers[, 9] == "Yes", ]

# Function to split and create new columns
split_and_create_columns <- function(data, column_name) {
  split_values <- strsplit(as.character(data[[column_name]]), ';')
  unique_values <- unique(unlist(split_values))
  
  for (value in unique_values) {
    data[[paste0(column_name, "_", value)]] <- sapply(split_values, function(x) as.numeric(value %in% x))
  }
  
  data[[column_name]] <- NULL
  return(data)
}

# List of columns to split for both data sets
columns_to_split_third <- c("Games played", "Gambling interest", "Gambling Platform","Gambling Deposit",
                            "Gambling Esport","Gambling Events", "Gambling Bets", "Gambling Motivation",
                            "Sport betting", "3rd Party Esports", "3rd Party Events", "3rd Party Games")

# Apply the function to each column of General gambling data set
for (column in columns_to_split_third) {
  Esports_gamblers <- split_and_create_columns(Esports_gamblers, column)
}

# Remove the 'Esport_gamble' column in-place
Esports_gamblers$`Esport gamble` <- NULL

# Change character's to factor #
character_columns <- sapply(Esports_gamblers, is.character)

# Convert character columns to factor
Esports_gamblers[character_columns] <- lapply(Esports_gamblers[character_columns], as.factor)

#Two seperate data sets for those who gamble on Esports vs those who gamble on Esports & 3rd Party#
# Create a subset for Third-party gamblers#
Third_party_platforms <- Esports_gamblers[Esports_gamblers$`Third Party` %in% c("Yes", "Maybe"),]

# Descriptive stats of Third party platforms #
desc_Third_party_platforms <- describe(Third_party_platforms)
# Export the table to a CSV file
write.csv(desc_Third_party_platforms, "Third_party_platforms_descriptive_stats.csv")
# Descriptive stats fo Esports gamblers and downloading CSV file #
desc_Esports_gamblers <- describe(Esports_gamblers)
write.csv(desc_Esports_gamblers, "desc_Esports_gamblers.csv")

# Getting levels and percentages of view time#
nview_time_levels <- levels(Esports_gamblers$`View time`)
print(view_time_levels)
# Getting levels and percentages of  Gambling levels#
view_gambling_levels <- levels(Esports_gamblers$`Gambling Frequency`)
print(view_gambling_levels)

# Getting levels and percentages of Age#
age_levels <- levels(Third_party_platforms$Age)
print(age_levels)

## Getting levels and percentages of Gaming time#
gaming_time_levels <- levels(Esports_gamblers$`Gaming time`)
print(gaming_time_levels)

## Getting levels and percentages of Regions#
region_levels <- levels(Esports_gamblers$Region)
print(region_levels)

## Getting levels and percentages of Income levels#
income_levels <- levels(Esports_gamblers$Income)
print(income_levels)

## Getting levels Of frequency#
Third_frequency <- levels(Esports_gamblers$`How has the availability of in-game items and virtual currencies influenced the frequency of your participation in eSports gambling on third-party websites?`)
print(Third_frequency)

# Count Gender and age from Esports_gamblers #
gender_count <- Esports_gamblers %>% 
  group_by(Gender) %>% 
  summarise(count = n())

# Calculate percentage for gender
gender_percentage <- gender_count %>%
  mutate(percentage = (count / sum(count)) * 100)

print(gender_percentage)

# Count age
age_count <- Esports_gamblers %>% 
  group_by(Age) %>% 
  summarise(count = n())

# Calculate percentage for age
age_percentage <- age_count %>%
  mutate(percentage = (count / sum(count)) * 100)

# Print the results
cat("Gender Count and Percentage:\n")
print(gender_count)
print(gender_percentage)

cat("\nAge Count and Percentage:\n")
print(age_count)
print(age_percentage)

# Count age Third party
age_count_third <- Third_party_platforms %>% 
  group_by(Age) %>% 
  summarise(count = n())

# Calculate percentage for age Third party
age_percentage_third <- age_count_third %>%
  mutate(percentage = (count / sum(count)) * 100)

# Count age Third party
Frequency_count <- Third_party_platforms %>% 
  group_by(`Gambling Frequency`) %>% 
  summarise(count = n())

# Calculate percentage for age Third party
Frequency_percentage <- Frequency_count %>%
  mutate(percentage = (count / sum(count)) * 100)

print(age_count_third)
print(age_percentage_third)
Frequency_percentage

# Percentage of PGSI gamblers in data set for Esports gamblers & Third party#
PGSI_score_count <- Esports_gamblers %>% 
  group_by(PGSI_score) %>% 
  summarise(count = n())

# Percentage of PGSI
PGSI_percentage <- PGSI_score_count %>%
  mutate(percentage = (count / sum(count)) * 100)

PGSI_percentage

# PGSI for Third party #
PGSI_score_count_third <- Third_party_platforms %>% 
  group_by(PGSI_score) %>% 
  summarise(count = n())

# Calculate percentage for gender
PGSI_percentage_third <- PGSI_score_count_third %>%
  mutate(percentage = (count / sum(count)) * 100)

PGSI_percentage
PGSI_percentage_third

# Select only numeric columns
numeric_columns <- Third_party_platforms %>% select_if(is.numeric)

# Filter out columns with zero standard deviation
non_constant_columns <- numeric_columns %>%
  select(names(which(sapply(numeric_columns, sd) != 0)))

# Calculate correlations
correlation_df <- data.frame(
  Variable = names(non_constant_columns),
  Correlation = as.numeric(cor(Third_party_platforms$PGSI_score, non_constant_columns, use = "complete.obs"))
)

# Filter out rows with missing values
correlation_df <- correlation_df[complete.cases(correlation_df),]

# Arrange by absolute correlation in descending order
correlation_df <- correlation_df[order(abs(correlation_df$Correlation), decreasing = TRUE),]

# Exclude the row with "PGSI_score" before displaying
top_10_correlated <- correlation_df %>%
  filter(Variable != "PGSI_score") %>%
  head(10)

# Print or view the top 10 correlated variables in a table
kable(top_10_correlated)


# Filter columns tha# Filter columns tha# Filter columns that have '3rd Party Esports' in their name
esports_columns <- Third_party_platforms %>%
  select(matches("3rd Party Esports"))

# Add PGSI_score to the dataset
esports_columns <- cbind(esports_columns, PGSI_score = Third_party_platforms$PGSI_score)

# Define PGSI score categories
esports_columns <- esports_columns %>%
  mutate(PGSI_category = cut(PGSI_score,
                             breaks = c(-Inf, 0, 2, 7, Inf),
                             labels = c("Non-problem gambler", "Low-risk gambler", "Moderate-risk gambler", "Problem gambler"),
                             include.lowest = TRUE))

esports_columns <- esports_columns[, !grepl("PGSI_score", names(esports_columns))]

# Sum the binary values (count of "1's") for each column
total_count <- esports_columns %>%
  group_by(PGSI_category) %>%
  summarise_all(~ sum(. == 1, na.rm = TRUE))


# Create a matrix with counts for each PGSI_category by column
count_matrix <- total_count %>%
  select(-PGSI_category)  # Exclude the PGSI_category column

# Calculate the percentage matrix for each PGSI_category by column
percentage_matrix <- count_matrix / rowSums(count_matrix) * 100

# Round the result to 2 decimal places
percentage_matrix <- round(percentage_matrix, 2)

print(count_matrix)

# Print the percentage matrix
print(percentage_matrix)
# Gather the data into long format for easier plotting
total_count_long <- total_count %>%
  gather(key = "Variable", value = "Count", -PGSI_category)

# Create a bar plot
ggplot(total_count_long, aes(x = PGSI_category, y = Count, fill = Variable)) +
  geom_bar(stat = "identity", position = "dodge", show.legend = TRUE) +
  labs(title = "Visualisation of 3rd Party Esports gambling by PGSI Category",
       x = "PGSI Category",
       y = "Count") +
  theme_minimal()

# Filter columns that have 'Sport betting' in their name
sports_betting_columns <- Third_party_platforms %>%
  select(matches("Sport betting"))

# Add PGSI_score to the dataset
sports_betting_columns <- cbind(sports_betting_columns, PGSI_score = Third_party_platforms$PGSI_score)

# Define PGSI score categories
sports_betting_columns <- sports_betting_columns %>%
  mutate(PGSI_category = cut(PGSI_score,
                             breaks = c(-Inf, 0, 2, 7, Inf),
                             labels = c("Non-problem gambler", "Low-risk gambler", "Moderate-risk gambler", "Problem gambler"),
                             include.lowest = TRUE))

sports_betting_columns <- sports_betting_columns[, !grepl("PGSI_score", names(sports_betting_columns))]

# Sum the binary values (count of "1's") for each column
total_count_sports <- sports_betting_columns %>%
  group_by(PGSI_category) %>%
  summarise_all(~ sum(. == 1, na.rm = TRUE))


# Gather the data into long format for easier plotting
total_count_sports_long <- total_count_sports %>%
  gather(key = "Variable", value = "Count", -PGSI_category)


# Create a bar plot for sports betting columns
ggplot(total_count_sports_long, aes(x = PGSI_category, y = Count, fill = Variable)) +
  geom_bar(stat = "identity", position = "dodge", show.legend = TRUE) +
  labs(title = "Visualisation of Sports Betting by PGSI Category",
       x = "PGSI Category",
       y = "Count") +
  theme_minimal()

# Define PGSI score categories
age_by_region <- Third_party_platforms %>%
  mutate(PGSI_category = cut(PGSI_score,
                             breaks = c(-Inf, 0, 2, 7, Inf),
                             labels = c("Non-problem gambler", "Low-risk gambler", "Moderate-risk gambler", "Problem gambler"),
                             include.lowest = TRUE))

# Count the occurrences of Age, PGSI_category, and Region
count_age_pgsi_region <- age_by_region %>%
  group_by(Age, PGSI_category, Region) %>%
  summarise(Count = n())

# Count the occurrences of Age, PGSI_category, and Region
count_age_pgsi_region_percentage <- age_by_region %>%
  group_by(Age, PGSI_category, Region) %>%
  summarise(Count = n()) %>%
  ungroup() %>%
  group_by(Age, Region) %>%
  mutate(Percentage = (Count / sum(Count)) * 100) %>%
  distinct(Age, Region, PGSI_category, .keep_all = TRUE) %>%
  pivot_wider(names_from = PGSI_category, values_from = Percentage)


# Create a bar plot with x-axis categories based on Age, subgrouped by PGSI_category, and split by Region
ggplot(count_age_pgsi_region, aes(x = reorder(Age, -Count), y = Count, fill = PGSI_category)) +
  geom_bar(stat = "identity", position = "stack", show.legend = TRUE) +
  labs(title = "Visualisation of PGSI Score by Age (Split by Region)",
       x = "Age",
       y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~Region, scales = "free_y")
# Define PGSI score categories
age_region_columns <- age_region_columns %>%
  mutate(PGSI_category = cut(PGSI_score,
                             breaks = c(-Inf, 0, 2, 7, Inf),
                             labels = c("Non-problem gambler", "Low-risk gambler", "Moderate-risk gambler", "Problem gambler"),
                             include.lowest = TRUE))

# Count the occurrences of Age, PGSI_category, and Region
count_age_pgsi_region <- age_region_columns %>%
  group_by(Age, PGSI_category, Region) %>%
  summarise(Count = n())

# Create a bar plot with x-axis categories based on the count of Age, subgrouped by PGSI_category, and split by Region
ggplot(count_age_pgsi_region, aes(x = reorder(Age, -Count), y = Count, fill = PGSI_category)) +
  geom_bar(stat = "identity", position = "stack", show.legend = TRUE) +
  labs(title = "Visualisation of Age Count by PGSI Category (Split by Region)",
       x = "Age",
       y = "Count") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  facet_wrap(~Region, scales = "free_y")

# Filter columns that have 'Gambling Motivations' or 'Gambling Frequency' in their name
motivations_and_frequency_columns <- Third_party_platforms %>%
  select(matches("Gambling Motivation|Gambling Frequency"))

# Assuming your data is stored in a data frame called motivations_data
total_count_motivations <- motivations_and_frequency_columns %>%
  group_by(motivations_and_frequency_columns$`Gambling Frequency`) %>%
  summarise(
    `Gambling Motivation_Entertainment` = sum(motivations_and_frequency_columns$`Gambling Motivation_Entertainment`),
    `Gambling Motivation_Making_a_profit` = sum(motivations_and_frequency_columns$`Gambling Motivation_Making a profit`),
    `Gambling Motivation_Thrill_and_excitement` = sum(motivations_and_frequency_columns$`Gambling Motivation_Thrill and excitement`),
    `Gambling Motivation_Peer_influence` = sum(motivations_and_frequency_columns$`Gambling Motivation_Peer influence`),
    `Gambling Motivation_Fandom` = sum(motivations_and_frequency_columns$`Gambling Motivation_Fandom for specific teams/players`),
  )


# Filter columns that have 'Gambling Motivations', 'Gambling Frequency', or 'Region' in their name
motivations_and_frequency_region_columns <- Third_party_platforms %>%
  select(matches("Gambling Motivation|Gambling Frequency|Region"))

# Remove NA and not motivated from chart #
motivations_and_frequency_region_columns <- motivations_and_frequency_region_columns[, -c(8, 10, 11)]

# Remove Gambling Motivation from start of all column names #
motivations_and_frequency_region_columns <- motivations_and_frequency_region_columns %>%
  rename_all(~gsub("Gambling Motivation_", "", .))

# Gather the data into long format for easier plotting, including 'Region'
data_long_region <- motivations_and_frequency_region_columns %>%
  gather(key = "Motivation", value = "Count", -`Gambling Frequency`, -Region)

# Create a stacked bar chart grouped by region
ggplot(data_long_region, aes(x = `Gambling Frequency`, y = Count, fill = Motivation)) +
  geom_bar(stat = "identity", position = "stack") +
  facet_wrap(~ Region, scales = "free_y", ncol = 2) +
  labs(title = "Stacked Bar Chart of Gambling Motivations by Frequency and Region",
       x = "Gambling Frequency",
       y = "Total Count") +
  theme_minimal()

# Observing the frequency of Health along with gambling frequency by region #
# Filter columns that have 'Gambling Motivations', 'Gambling Frequency', or 'Region' in their name
motivations_and_frequency_region_columns <- Third_party_platforms %>%
  select(matches("Gambling Motivation|Gambling Frequency|Region"))

# Remove NA and not motivated from chart #
motivations_and_frequency_region_columns <- motivations_and_frequency_region_columns[, -c(8, 10, 11)]

# Remove Gambling Motivation from start of all column names #
motivations_and_frequency_region_columns <- motivations_and_frequency_region_columns %>%
  rename_all(~gsub("Gambling Motivation_", "", .))

# Gather the data into long format for easier plotting, including 'Region'
data_long_region <- motivations_and_frequency_region_columns %>%
  gather(key = "Motivation", value = "Count", -`Gambling Frequency`, -Region)

# Create a stacked bar chart grouped by region
ggplot(data_long_region, aes(x = `Gambling Frequency`, y = Count, fill = Motivation)) +
  geom_bar(stat = "identity", position = "stack") +
  facet_wrap(~ Region, scales = "free_y", ncol = 2) +
  labs(title = "Stacked Bar Chart of Gambling Motivations by Frequency and Region",
       x = "Gambling Frequency",
       y = "Total Count") +
  theme_minimal() 

# Gambling health by gambling frequency #
ggplot(Third_party_platforms_health, aes(x = `Gambling Frequency`, fill = Health)) +
  geom_bar(position = "dodge", color = "black", stat = "count") +
  labs(title = "Impact of Gambling frequency on mental health",
       x = "Gambling Frequency",
       y = "Count",
       fill = "Health") +
  theme_minimal()

# Convert character columns to factors (if needed)
Third_party_platforms <- as.data.frame(lapply(Third_party_platforms, as.factor))

# Perform KNN imputation
imputed_data <- kNN(Third_party_platforms)

# Extract column names from the original data
original_column_names <- colnames(Third_party_platforms)

# Identify columns with only one factor level
one_level_columns <- sapply(imputed_data, function(x) length(levels(factor(x))) == 1)

# Remove columns with only one factor level
imputed_data <- imputed_data[, !one_level_columns]

# Remove columns 91 to 95 from imputed_data
imputed_data <- imputed_data[, -c(87:88)]


# Convert PGSI_score to numeric
imputed_data$PGSI_score <- as.numeric(as.character(imputed_data$PGSI_score))
# Assuming 'Modified_data' is your data frame
Modified_data_desc <- describe(Modified_data)

# Fit the linear regression model
model <- lm(PGSI_score ~ ., data = imputed_data)


# Print a summary of the linear regression model
summary(model)


