install.packages("corrplot")
install.packages("dplyr")
install.packages("knitr")

library(readxl)
library(Rcpp)
library(corrplot)
library(dplyr)
library(knitr)

eSports_Gambling_risk_study_1_285_1_ <- read_excel("eSports Gambling risk study(1-285) (1).xlsx")

Main_data <- eSports_Gambling_risk_study_1_285_1_

Modified_data <- eSports_Gambling_risk_study_1_285_1_

# Remove columns 1 to 9
Modified_data <- Modified_data[, -c(1:9)]

# Assuming your data frame is named Modified_data
answer_mapping <- c('Never' = 0, 'Sometimes' = 1, 'Most of the time' = 2, 'Almost always' = 3)

# Columns 29 to 37
answer_columns <- Modified_data[, 24:32]

# Apply the mapping for PGSI #
mapped_answers <- sapply(answer_columns, function(column) {
  sapply(column, function(answer) {
    answer_mapping[as.character(answer)]
  })
})

# Create a new column with the total scores
Modified_data$PGSI_score <- rowSums(mapped_answers, na.rm = TRUE)

#Remove columns 24 : 32 (PGSI responses)#
Modified_data <- Modified_data[, -c(24:32)]

# drop NA obs
Modified_data <- Modified_data[-201, , drop = FALSE]

# Get the names of all columns excluding the final column
columns_to_convert <- setdiff(names(Modified_data), "PGSI score")

# Convert all columns to factors
Modified_data[, columns_to_convert] <- lapply(Modified_data[, columns_to_convert], as.factor)

# Convert PGSI score to Numeric #
Modified_data$PGSI_score <- as.numeric(Modified_data$PGSI_score)

#Descriptive statistics#
summary_stats <- summary(Modified_data)
summary_stats

# Assuming 'Modified_data' is your data frame
column_names <- names(Modified_data)


#Splitting Data set into 4 Regions#

# List of regions
regions <- c("Middle East/Africa", "Europe", "Asian Pacific", "Americas")

# Create an empty list to store data frames for each region
region_data_frames <- list()

# Loop through each region
for (region in regions) {
  # Subset the original data frame based on the region
  region_df <- subset(Modified_data, Modified_data$`Which region are you from?` == region)  # Assuming 'Regions' is the correct column name
  
  # Add the region data frame to the list
  region_data_frames[[region]] <- region_df
}

# Print the names of the data frames in the list
print(names(region_data_frames))

# Access the data frame for a specific region (e.g., "Middle East/Africa")
middle_east_africa_df <- region_data_frames[["Middle East/Africa"]]
Europe_df <- region_data_frames[["Europe"]]
Americas_df <- region_data_frames[["Americas"]]
Asia_Pacific_df <- region_data_frames[["Asian Pacific"]]

# Data frame for those who gamble on third-party platforms #
names(Modified_data)[25] <- "Third Party"

# Create a subset for Third-party gamblers#
Third_party_platforms <- Modified_data[Modified_data$`Third Party` %in% c("Yes", "Maybe","No"), ]

# Renaming column headers#
names(Third_party_platforms)[15] <- "Deposit"
names(Third_party_platforms)[20] <- "Sport betting"
names(Third_party_platforms)[26] <- "Third Party Gambling Amount"
names(Third_party_platforms)[27] <- "Third Party Esports"
names(Third_party_platforms)[32] <- "Third Party Games"
names(Third_party_platforms)[31] <- "Third Party Gambling"
names(Third_party_platforms)[29] <- "Frequency"
names(Third_party_platforms)[3] <- "Region"

# Assuming your dataset is named 'subset_data'
Third_Party_platforms <- Third_party_platforms[complete.cases(Third_party_platforms$`Third Party Games`),]

# Assuming your dataset is named 'subset_data'
Third_Party_platforms <- Third_Party_platforms[complete.cases(Third_Party_platforms$`Third Party Esports`), ]

Third_Party_platforms <- Third_Party_platforms[complete.cases(Third_Party_platforms$`Third Party Gambling`), ]

# Create new data frame to see correlation between Third Party Esports, Third Party Games & Third Party Gambling with PGSI
correlation_data <- Third_Party_platforms[, c('Third Party Esports', 'Third Party Games', 'Third Party Gambling','Region'
                                              ,'Sport betting', 'PGSI_score')]

# Split the 'Third Party Esports' column based on ';'
games_split <- strsplit(as.character(correlation_data$`Third Party Esports`), ';')

# Get unique game names
unique_games <- unique(unlist(games_split))

# Create new columns for each game
for (game in unique_games) {
  correlation_data[[game]] <- sapply(games_split, function(x) as.numeric(game %in% x))
}

# Remove the original 'Games' column
correlation_data$`Third Party Esports` <- NULL


# Split the 'Third Party Games' column based on ';'
Gambling_split <- strsplit(as.character(correlation_data$`Third Party Games`), ';')

# Get unique game names
unique_gambling <- unique(unlist(Gambling_split))

# Create new columns for each game
for (gambling in unique_gambling) {
  correlation_data[[gambling]] <- sapply(Gambling_split, function(x) as.numeric(gambling %in% x))
}

# Remove the original 'Third Party Gambling' column
correlation_data$`Third Party Games` <- NULL

# Assuming your dataset is named 'subset_data'
Third_Party_platforms <- Third_Party_platforms[complete.cases(Third_Party_platforms$`Third Party Esports`), ]

Third_Party_platforms <- Third_Party_platforms[complete.cases(Third_Party_platforms$`Third Party Gambling`), ]


# Split the 'Third Party Esports' column based on ';'
games_split <- strsplit(as.character(correlation_data$`Third Party Esports`), ';')

# Get unique game names
unique_games <- unique(unlist(games_split))

# Create new columns for each game
for (game in unique_games) {
  correlation_data[[game]] <- sapply(games_split, function(x) as.numeric(game %in% x))
}

# Remove the original 'Games' column
correlation_data$`Third Party Esports` <- NULL


# Split the 'Third Party Games' column based on ';'
Gambling_split <- strsplit(as.character(correlation_data$`Third Party Games`), ';')

# Get unique game names
unique_gambling <- unique(unlist(Gambling_split))

# Create new columns for each game
for (gambling in unique_gambling) {
  correlation_data[[gambling]] <- sapply(Gambling_split, function(x) as.numeric(gambling %in% x))
}

# Remove the original 'Third Party Games' column
correlation_data$`Third Party Games` <- NULL

# Split the 'Third Party Gambling' column based on ';'
Esports_gambling <- strsplit(as.character(correlation_data$`Third Party Gambling`), ';')

# Get unique game names
unique_esports_gambling <- unique(unlist(Esports_gambling))

# Create new columns for each game
for (esportgamble in unique_esports_gambling) {
  correlation_data[[esportgamble]] <- sapply(Esports_gambling, function(x) as.numeric(esportgamble %in% x))
}

# Remove the original 'Third Party Games' column
correlation_data$`Third Party Gambling` <- NULL

# Split the 'Sport betting' column based on ';'
sport_betting <- strsplit(as.character(correlation_data$`Sport betting`), ';')

# Get unique game names
unique_sportbetting <- unique(unlist(sport_betting))

# Create new columns for each game
for (sportbet in unique_sportbetting) {
  correlation_data[[sportbet]] <- sapply(sport_betting, function(x) as.numeric(sportbet %in% x))
}

# Remove the original 'Third Party Games' column
correlation_data$`Sport betting` <- NULL

# Split the 'Deposit' column based on ';'
deposit <- strsplit(as.character(correlation_data$Deposit), ';')

# Get unique deposit types
unique_deposit <- unique(unlist(deposit))

# Create new columns for each deposit type
for (dep in unique_deposit) {
  # Create a new column name based on the deposit type
  column_name <- paste0("Deposit_", dep)
  
  # Assign the numeric values to the new column
  correlation_data[[column_name]] <- sapply(deposit, function(x) as.numeric(dep %in% x))
}

# Remove the original 'Deposit' column
correlation_data$Deposit <- NULL


# Move 'PGSI_score' to the last column
correlation_data <- correlation_data %>%
  select(-PGSI_score, everything(), PGSI_score)

# Extract the 'PGSI_score' column
pgsi_score_column <- correlation_data$PGSI_score

# Select the columns you want to include in the correlation analysis
selected_columns <- setdiff(names(correlation_data), c("PGSI_score", "Region"))

# Create a subset of the data with the selected columns
subset_data_selected <- correlation_data[, selected_columns]

# Calculate the correlation between each column and 'PGSI_score'
correlation_with_pgsi <- sapply(subset_data_selected, function(column) cor(column, pgsi_score_column, use="complete.obs"))

# Print the correlation values
print(correlation_with_pgsi)

# Convert the correlation results to a data frame
correlation_df <- data.frame(Variable = names(correlation_with_pgsi), Correlation = correlation_with_pgsi)

# Sort the data frame by absolute values of the correlation coefficients in descending order
correlation_df <- correlation_df[order(-abs(correlation_df$Correlation)), ]

kable(correlation_df)

# Filter for specific variables: 'Crash', 'Plinko', 'Roulette', 'Case_battles'
variables_of_interest <- c('Crash', 'Plinko', 'Roulette', 'Case battles')
correlation_df_games <- correlation_df[correlation_df$Variable %in% variables_of_interest, ]

# Sort the data frame by absolute values of the correlation coefficients in descending order
correlation_df_games <- correlation_df_games[order(-abs(correlation_df_games$Correlation)), ]

# Print the filtered and sorted correlation results
print(correlation_df_games)

# Assuming 'Crash', 'Plinko', 'Roulette', 'Case_battles' are the column names in your data frame
variables_of_interest <- c('Crash', 'Plinko', 'Roulette', 'Case_battles')

# Extract the correlation of the specified variables with 'correlation_with_pgsi'
correlation_results <- data.frame(
  Variable = variables_of_interest,
  Correlation = sapply(variables_of_interest, function(variable) cor(data[['correlation_with_pgsi']], data[[variable]]))
)

# Print the correlation results
print(correlation_results)

# Fit a linear regression model
model <- lm(PGSI_score ~ ., data = correlation_data)

regression_table <- model

# Create a table with regression results
regression_table <- stargazer(model, type = "html", title = "Linear Regression Results", out = "regression_table.html")

# Save the HTML table to a file
writeLines(regression_table, "regression_table.html")

rm(list=ls())

